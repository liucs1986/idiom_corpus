The idioms are labelled using the tag '<u></u>'.
Annotation 1 is used as the gold standard.